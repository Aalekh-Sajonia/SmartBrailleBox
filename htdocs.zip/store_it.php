<html>
<head>
<title> Brailled! </title>
<meta name="viewport" content="width=device-wdith, initial-scale=1.0, user-scalable=no">
<link href="bootstrap.css" rel="stylesheet">
</head>
<body style="background-color: #007bffa1;">
<div style="margin-top:10px; background-image: url(background.jpg); background-repeat: repeat; border-radius:7.0px; margin-left:10px; margin-right:10px; min-height:95%; box-shadow: 5px 7px 14px 0px black;">
<script src="jquery.min.js"></script>
<script src="bootstrap.js"></script>
<?php
$name = empty($_POST["name"]) ? "" : $_POST["name"];
if(!$name){header("location:index.html?name=$name");}
else
{
$file = "Geek/06771720_name.txt";
$a = fopen($file, "w");
fwrite($a,$name);
fclose($a);
$a = fopen($file, "r");
echo '<center><table border=4 style="max-width:90%; width:90%;" class="table table-hover">';
echo '<caption><center><h3>Your Input Text:</h3></center></caption>';
while(!feof($a))
{
  echo "<tr><td style='margin-left:10px; margin-right:10px; width:90%; padding:10px;'>".fgets($a)."</td></tr></table></center>";
  }
fclose($a);
}
?>
<center>
<br><h2><span class="glyphicon glyphicon-ok-circle"></span> Brailled Successfully!</h2><br>
<form action="index.html">
<br>
<input class="form-control" style="width: 30%; align: center;" type="submit" value="Insert Again">
</form>
</center>
</div>
</body>
</html>
