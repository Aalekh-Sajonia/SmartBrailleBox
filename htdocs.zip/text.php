<?php

$fh = fopen('Geek/06771720_name.txt','r');
while ($line = fgets($fh)) {
  echo($line);
  $file = "braille.txt";
  $a = fopen($file, "w+");
  fwrite($a,$line."\r\n");
  fclose($a);
  $a = fopen($file, "r");
}
fclose($fh);
?>