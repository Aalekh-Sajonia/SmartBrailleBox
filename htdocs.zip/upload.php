
<?PHP
  if(!empty($_FILES['uploaded_file']))
  {
    $path = "Geek/06771720_name.txt";
    #$path = $path . basename( $_FILES['uploaded_file']['name']);
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) {
      #echo "The file ".  basename( $_FILES['uploaded_file']['name']). 
      #" has been uploaded";
      header( 'Location: http://localhost/second1.html' ) ;
    } else{
      header( 'Location: http://localhost/second2.html' ) ;
    }
  }
?>
