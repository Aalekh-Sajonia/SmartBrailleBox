<?php

$server_ip = gethostbyname(gethostname());
 
//upload url
$upload_url = 'http://'.$server_ip.'/Geek/';
 
//response array
$response = array();
 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
 
    //checking the required parameters from the request
    if(isset($_POST['name']) and isset($_POST['speed']) and isset($_POST['id'])){
        $name = $_POST['name'];
		$speed = $_POST['speed'];
		$id = $_POST['id'];
		$my_file = $id . '_name.txt';
		$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
		fwrite($handle, $name);		
		fclose($handle);
		$my_files = $id.'_speed.txt';
		$handler = fopen($my_files, 'w') or die('Cannot open file:  '.$my_files);
		fwrite($handler, $speed);		
		fclose($handler);
        //trying to save the file in the directory
            //saving the file
        $response['status'] = "written";
		$response['error'] = false;
        
    }else{
        $response['error']=true;
        $response['message']='Please choose a file';
		echo $response['error'];
    }
    //displaying the response
    echo json_encode($response);
}