<?php

define('DB_HOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','root');
define('DB_NAME','android');

 
//server ip
$server_ip = gethostbyname(gethostname());
 
//upload url
$upload_url = 'http://'.$server_ip.'/Geek/';
 
//response array
$response = array();
 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
    if(isset($_POST['name']) and isset($_FILES['pdf']['name']) and isset($_POST['speed']) and isset($_POST['id'])){
		
		$id = $_POST['id'];
        $name = $id . '_name.txt';
		$speed  = $_POST['speed'];
		
        //getting file info from the request
        $fileinfo = pathinfo($_FILES['pdf']['name']);
        //getting the file extension
        $extension = $fileinfo['extension'];
		
 
        //trying to save the file in the directory
        try{
            //saving the file
            move_uploaded_file($_FILES['pdf']['tmp_name'],$name);
			$my_files = $id."_speed.txt";
		$handle = fopen($my_files, 'w') or die('Cannot open file:  '.$my_files);
			fwrite($handle, $speed);		
			fclose($handle);
			echo "DONE";
        }catch(Exception $e){
            $response['error']=true;
            $response['message']=$e->getMessage();
        } 
    }else{
        $response['error']=true;
        $response['message']='Please choose a file';
    }
    
    //displaying the response
    echo json_encode($response);
}