<?php
 
//importing dbDetails file
define('DB_HOST','127.0.0.1');
define('DB_USERNAME','root');
define('DB_PASSWORD','root');
define('DB_NAME','android');
 
//response array
$response = array();
 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
 
    //checking the required parameters from the request
    if(isset($_POST['id'])){
        //connecting to the database
        $con = mysqli_connect(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_NAME) or die('Unable to Connect...');
        //getting name from the request
        $id = $_POST['id'];
		$sql = "SELECT * FROM dynamic where id = " .$id;
		$result = mysqli_query($con,$sql) or die(mysql_error());
		if ($result->num_rows > 0) {
			$response['valid'] = true;
			$con->close();
		} 
		else {
			$response['valid'] = false;
			$handle = fopen("name.txt", 'w') or die('Cannot open file:  '.$my_file);
			fwrite($handle, "Error!!!");			
			fclose($handle);
		}
        
    }else{
        $response['error']=true;
		echo $response['error'];
    }
    //displaying the response
   echo json_encode($response);
}
 
/*
We are generating the file name
so this method will return a file name for the image to be upload
*/